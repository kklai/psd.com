        <div id="sidebar">

        

            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>

        

                <div class="side_box">

                    <h3>Recent Posts</h3>

                    

                    <ul>

                      <li>Angle Pulse Poster</li>

                      <li>Designers Poster</li>

                      <li>Angle Pulse Poster</li>

                      <li>Designers Poster</li>

                      <li>Angle Pulse Poster</li>

                      <li>Designers Poster</li>                  

                    </ul>

                </div><!--//side_box-->

                

            <?php endif; ?>                

        

        </div><!--//sidebar-->